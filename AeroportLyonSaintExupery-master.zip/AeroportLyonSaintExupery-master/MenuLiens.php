<!DOCTYPE html>
<html lang="fr">
<meta charset="UTF-8">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>Statistiques des vols</title>
</head>
<body class="php">
<p>
    <ul class="menu">
        <li>
            <a href='Connexion.php'>Connexion</a>
        </li>
        <li>
            <a href='Inscription.php'>Inscription</a>
        </li>
        <li>
            <a href='VisualisationDesVols.php'>Visualisation des vols</a>
        </li>
        <li>
            <a href='Aeroport.php'>Aéroport</a>
        </li>
        <li>
            <a href='Statistiques.php'>Statistiques</a>
        </li>
        <li>
            <a href='InsertionClient.php'>Ajout client</a>
        </li>
        <li>
            <a href='InsertionVol.php'>Ajout vol</a>
        </li>
        <li>
            <a href='AchatBillet.php'>Acheter ses billet</a>
        </li>
        <li>
            <a href='Informations.php'>Informations</a>
        </li>
    </ul>
</p>

</body>
</html>